/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project17;

/**
 *
 * @author ADMIN
 */
import java.util.*;
public class Project17 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        byte n = sc.nextByte();
        List<GameThu> lis = new ArrayList<>();
        sc.nextLine();
        while(n-->0){
            String ma = sc.nextLine();
            String na = sc.nextLine();
            String tr = sc.nextLine();
            String en = sc.nextLine();
            GameThu gt = new GameThu(ma,na,tr,en);
            lis.add(gt);
        }
        Collections.sort(lis);
        for(GameThu gt:lis){
            gt.output();
        }
    }
}
