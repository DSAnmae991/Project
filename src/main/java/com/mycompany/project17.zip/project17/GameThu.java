/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project17;

/**
 *
 * @author ADMIN
 */
import java.time.*;
public class GameThu implements Comparable<GameThu>{
    private String ma,na;
    private LocalTime dn,dt;
    private Duration dr;

    public GameThu(String ma, String na, String tr, String en) {
        this.ma = ma;
        this.na = na;
        String a[] = tr.split(":");
        dn = LocalTime.of(Integer.parseInt(a[0]),Integer.parseInt(a[1]));
        String b[] = en.split(":");
        dt = LocalTime.of(Integer.parseInt(b[0]),Integer.parseInt(b[1]));
        dr = Duration.between(dn, dt);
    }
    @Override
    public int compareTo(GameThu gt){
        return -Long.compare(this.dr.toMinutes(),gt.dr.toMinutes());
    }
    public void output(){
        System.out.println(ma+" "+na+" "+dr.toHours()+" gio "+(dr.toMinutes()%60)+" phut");
    }
}
